#database 
 - artikel = ada status konten atau page
 - tag
 - user dengan role
 - menu
 - slider
 - gambar
